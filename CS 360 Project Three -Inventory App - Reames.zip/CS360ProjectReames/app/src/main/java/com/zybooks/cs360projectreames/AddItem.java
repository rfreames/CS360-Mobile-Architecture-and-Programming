package com.zybooks.cs360projectreames;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItem extends AppCompatActivity {

    Button btn_add;
    EditText et_name, et_quantity;
    private String SMSPermission = Manifest.permission.SEND_SMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Adding back button to action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(true);

        // Connects variables below with views from activity_add_item.xml
        btn_add = findViewById(R.id.btn_add);
        et_name = findViewById(R.id.et_name);
        et_quantity = findViewById(R.id.et_quantity);

        // Sets clicklistener for submit button and reviews input prior to updating database
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v) {

                Item newItem;

                try {
                    if(et_name.getText().toString().equals("")) {
                        Toast.makeText(AddItem.this, "Please enter name",
                                Toast.LENGTH_SHORT).show();
                    }
                    else {
                        newItem = new Item(-1, et_name.getText().toString(),
                                Integer.parseInt(et_quantity.getText().toString()));

                        // Add item to database
                        DatabaseHelper databaseHelper = new DatabaseHelper(AddItem.this);
                        boolean success = databaseHelper.addOne(newItem);

                        if (success) {
                            Toast.makeText(AddItem.this, "Added " + et_name.getText().toString(),
                                    Toast.LENGTH_SHORT).show();

                            // SMS message
                            if (ContextCompat.checkSelfPermission(AddItem.this, SMSPermission)
                                    == PackageManager.PERMISSION_GRANTED &&
                                    newItem.getQuantity() == 0) {
                                String phoneNumber = getResources().getString(R.string.this_phone);
                                SmsManager sms = SmsManager.getDefault();
                                sms.sendTextMessage(phoneNumber, null,
                                        newItem.getName() + " inventory is 0",
                                        null, null);
                            }
                        }
                        else {
                            Toast.makeText(AddItem.this, "Failed to add " + et_name.getText().toString(),
                                    Toast.LENGTH_SHORT).show();
                        }
                        Intent intent = new Intent(AddItem.this, MainActivity.class);
                        startActivity(intent);
                    }
                }
                catch (Exception e) {
                    Toast.makeText(AddItem.this, "invalid format",
                                    Toast.LENGTH_SHORT).show();
                    newItem = new Item(-1, "error", 1);
                }
            }
        });
    }

    // Back button
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}