package com.zybooks.cs360projectreames;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AdjustItem extends AppCompatActivity {

    private TextView mName;
    private EditText mEditQuantity;
    private Button btn_adjust;
    private String SMSPermission = Manifest.permission.SEND_SMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adjust_item);

        // Links variables below with views from activity_adjust_item.xml
        mName = findViewById(R.id.adjust_item_name);
        mEditQuantity = findViewById(R.id.adjust_item_quantity);
        btn_adjust = findViewById(R.id.btn_adjust);

        // Bundle used to get item id passed in to adjust - if no id, no adjustment can be made
        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            int thisItemId = extras.getInt("id");
            DatabaseHelper databaseHelper = new DatabaseHelper(AdjustItem.this);
            Item currentItem = databaseHelper.selectOne(thisItemId);

            // Sets values for views based on item selected
            mName.setText(currentItem.getName());
            mEditQuantity.setHint("Current quantity: " + currentItem.getQuantity());

            // Used to review user input then update database with new quantity
            btn_adjust.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick (View v) {

                    Item adjustedItem;

                    try {
                        adjustedItem = new Item(currentItem.getId(), currentItem.getName(),
                                Integer.parseInt(mEditQuantity.getText().toString()));

                        // Add item to database
                        DatabaseHelper databaseHelper = new DatabaseHelper(AdjustItem.this);
                        boolean success = databaseHelper.adjustOne(adjustedItem);

                        if (success) {
                            Toast.makeText(AdjustItem.this, "Adjusted " + currentItem.getName().toString(),
                                    Toast.LENGTH_SHORT).show();

                            // SMS message
                            if (ContextCompat.checkSelfPermission(AdjustItem.this, SMSPermission)
                                    == PackageManager.PERMISSION_GRANTED &&
                                    adjustedItem.getQuantity() == 0) {
                                String phoneNumber = getResources().getString(R.string.this_phone);
                                SmsManager sms = SmsManager.getDefault();
                                sms.sendTextMessage(phoneNumber, null,
                                        adjustedItem.getName() + " inventory is 0",
                                        null, null);
                            }
                        }
                        else {
                            Toast.makeText(AdjustItem.this, "Failed to adjust " + currentItem.getName().toString(),
                                    Toast.LENGTH_SHORT).show();
                        }
                        Intent intent = new Intent(AdjustItem.this, MainActivity.class);
                        startActivity(intent);
                    }
                    // Generally if user leaves input blank
                    catch (Exception e) {
                        Toast.makeText(AdjustItem.this, "invalid format",
                                Toast.LENGTH_SHORT).show();
                        adjustedItem = new Item(-1, "error", 1);
                    }
                }
            });
        }


        // Adding back button to action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(true);
    }

    // Back button
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}