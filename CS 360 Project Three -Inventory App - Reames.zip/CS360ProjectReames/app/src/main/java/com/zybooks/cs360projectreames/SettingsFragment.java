package com.zybooks.cs360projectreames;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;

import org.w3c.dom.Text;

public class SettingsFragment extends Fragment {

    Button btn_log_out, notifications_button;
    TextView notification_info;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        // Connects log out button to view, then returns to log in screen when pressed
        btn_log_out = view.findViewById(R.id.btn_logout);
        btn_log_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplicationContext(), LogIn.class);
                startActivity(intent);
            }
        });

        // Requests user permission to send SMS on first press, then refers to check app
        // permissions under device settings after initial accept / decline
        notification_info = view.findViewById(R.id.notification_info);
        notifications_button = view.findViewById(R.id.notifications_button);
        notifications_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hasSMSPermissions();
                notification_info.setText(R.string.updated_notifications_info);
            }
        });
        // Inflate the layout for this fragment
        return view;
    }

    // Used to check for permission to send SMS
    private final int REQUEST_SMS_CODE = 0;
    private void hasSMSPermissions() {
        String SMSPermission = Manifest.permission.SEND_SMS;
        if (ContextCompat.checkSelfPermission(getActivity().getApplicationContext(), SMSPermission)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                        new String[] { SMSPermission }, REQUEST_SMS_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_SMS_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted!
                }
                else {
                    // Permission denied!
                }
            }
        }
    }
}