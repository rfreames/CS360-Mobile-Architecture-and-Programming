package com.zybooks.cs360projectreames;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

// Used for the main inventory screen containing inventory grid, as well as settings

// Deleting an item is included in code here as it is done through an alert, rather than an activity
public class InventoryFragment extends Fragment {

    DatabaseHelper databaseHelper;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_inventory, container, false);

        // Click listener for the RecyclerView
        View.OnClickListener onClickListener = itemView -> {

            // Create fragment arguments containing the selected item ID
            int selectedItemId = (int) itemView.getTag();
            Bundle args = new Bundle();
            args.putInt(DatabaseHelper.COLUMN_ID, selectedItemId);

            // Passes argument to AdjustItem and starts adjustment activity
            Intent intent = new Intent(getActivity().getApplicationContext(), AdjustItem.class);
            intent.putExtra("id", args.getInt(DatabaseHelper.COLUMN_ID));
            startActivity(intent);
        };

        // Setting up database connection and recycler view
        databaseHelper = new DatabaseHelper(getActivity().getApplicationContext());
        RecyclerView recyclerView = view.findViewById(R.id.inventory_recycler_view);
        List<Item> items = databaseHelper.selectAll();
        // Passes items to recycler view / click listener
        recyclerView.setAdapter(new ItemRecycler(items, onClickListener));

        // Sets up floating action button to start add item activity
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), AddItem.class);
                startActivity(intent);
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    // Required for recyclerview to work
    private class ItemRecycler extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItems;

        private final View.OnClickListener mOnClickListener;

        // Connects items and clicklistener to this recyclerview
        public ItemRecycler(List<Item> items, View.OnClickListener onClickListener) {
            mItems = items;
            mOnClickListener = onClickListener;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        // Used to set individual item display in recyclerview
        @Override
        public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
            Item item = mItems.get(position);
            holder.bind(item);
            holder.itemView.setTag(item.getId());
            holder.itemView.setOnClickListener(mOnClickListener);

            // Delete alert / notification
            holder.mDeleteButton.setOnClickListener(deleteItem -> {

                AlertDialog.Builder deleteDialog = new AlertDialog.Builder(requireActivity(),
                        androidx.appcompat.R.style.Base_Theme_AppCompat_Light_Dialog_Alert);

                deleteDialog.setTitle("Delete " + holder.mName.getText().toString() + "?")
                    .setPositiveButton("Delete", (dialog, whichButton) -> {

                        if (databaseHelper.deleteOne(item)) {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Deleted " + item.getName().toString(),
                                    Toast.LENGTH_SHORT).show();
                            mItems.remove(position);
                            notifyItemRemoved(position);
                        }
                        else {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Failed to delete " + item.getName().toString(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .create();
                deleteDialog.show();
            });
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }
    }

    // Connects recycler_view_items layout with recyclerview code
    private static class ItemHolder extends RecyclerView.ViewHolder {
        private final TextView mName, mQuantity;
        private final ImageButton mDeleteButton;
        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            mName = itemView.findViewById(R.id.item_name_text_view);
            mQuantity = itemView.findViewById(R.id.quantity_text_view);
            mDeleteButton = itemView.findViewById(R.id.delete_item);
        }

        public void bind(Item item) {
            mName.setText(item.getName());
            mQuantity.setText(String.valueOf(item.getQuantity()));
        }
    }
}


