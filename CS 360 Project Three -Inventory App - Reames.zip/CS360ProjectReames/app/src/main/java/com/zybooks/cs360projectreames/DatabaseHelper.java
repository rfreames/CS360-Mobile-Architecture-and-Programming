package com.zybooks.cs360projectreames;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Table information for inventory items
    public static final String ITEM_TABLE = "ITEM_TABLE";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_ITEM_NAME = "ITEM_NAME";
    public static final String COLUMN_ITEM_QUANTITY = "ITEM_QUANTITY";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "itemInventory.db", null, 1);
    }

    // Called first time database is accessed
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + ITEM_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_ITEM_NAME + " TEXT, " + COLUMN_ITEM_QUANTITY + " INT)";

        db.execSQL(createTableStatement);
    }

    // When version number of database changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // Adds one item, not including id which is autoincremented with each database item
    public boolean addOne(Item itemModel) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM_NAME, itemModel.getName());
        cv.put(COLUMN_ITEM_QUANTITY, itemModel.getQuantity());

        long insert = db.insert(ITEM_TABLE, null, cv);

        if (insert == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    // Used to update inventory quantity
    public boolean adjustOne(Item itemModel) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM_NAME, itemModel.getName());
        cv.put(COLUMN_ITEM_QUANTITY, itemModel.getQuantity());

        long insert = db.update(ITEM_TABLE, cv, COLUMN_ID + " = ?", new String[] { Integer.toString(itemModel.getId()) });

        if (insert == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    // Selects all items in database and returns in list, used to populate recyclerview
    public List<Item> selectAll() {

        List<Item> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + ITEM_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) {
            // Loop through cursor and create new item objects, then add to returnList
            do {
                int itemId = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int itemQuantity = cursor.getInt(2);

                Item newItem = new Item(itemId, itemName, itemQuantity);
                returnList.add(newItem);

            } while (cursor.moveToNext());
        }
        else {
            // Nothing in list
        }

        cursor.close();
        db.close();

        return returnList;
    }

    // Searches for specific item based on id, used when adjusting item quantity primarily
    // to populate screen with name
    public Item selectOne(int id) {

        Item returnItem;

        String queryString = "SELECT * FROM " + ITEM_TABLE + " WHERE " + COLUMN_ID + " = " + id;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) {
            int itemId = cursor.getInt(0);
            String itemName = cursor.getString(1);
            int itemQuantity = cursor.getInt(2);

            returnItem = new Item(itemId, itemName, itemQuantity);

            cursor.close();
            db.close();
            return returnItem;
        }
        else return null;
    }

    // Deletes one item from database
    public boolean deleteOne(Item item) {

        SQLiteDatabase db = this.getWritableDatabase();

        int success = db.delete(ITEM_TABLE, COLUMN_ID + " = ?", new String[] { Integer.toString(item.getId()) });

        if (success == 1) {
            return true;
        }
        else {
            return false;
        }
    }
}
