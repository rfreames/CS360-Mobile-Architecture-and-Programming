package com.zybooks.cs360projectreames;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;

public class LogIn extends AppCompatActivity {

    Button btn_login, btn_create_account;
    EditText et_username, et_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        // Assigning buttons / edit texts to views
        btn_login = findViewById(R.id.btn_login);
        btn_create_account = findViewById(R.id.btn_create_account);
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);

        // Click listener for the login button
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // checks if both fields have data
                    if(et_username.getText().toString().equals("") ||
                            et_password.getText().toString().equals("")) {
                        Toast.makeText(LogIn.this, "Please enter both fields",
                                Toast.LENGTH_SHORT).show();
                    }
                    // If so, searches database for specified user, starting MainActivity
                    // (inventory) if username and password match what is in database
                    else {
                        UserHelper userHelper = new UserHelper(LogIn.this);
                        User signInAccount = userHelper.selectOne(et_username.getText().toString());
                        if (signInAccount == null) {
                            Toast.makeText(LogIn.this, "Account not found",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            if (Objects.equals(signInAccount.getPassword(), et_password.getText().toString())) {
                                Intent intent = new Intent(LogIn.this, MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(LogIn.this, "Invalid password",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
                catch (Error e) {
                    Toast.makeText(LogIn.this, "Error logging in: " + e,
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Click listener for the create account button
        btn_create_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // Checks that both fields were entered
                    if(et_username.getText().toString().equals("") ||
                            et_password.getText().toString().equals("")) {
                        Toast.makeText(LogIn.this, "Please enter both fields",
                                Toast.LENGTH_SHORT).show();
                    }
                    else {
                        UserHelper userHelper = new UserHelper(LogIn.this);
                        User signInAccount = userHelper.selectOne(et_username.getText().toString());
                        if (signInAccount == null) {
                            User newAccount = new User(et_username.getText().toString(),
                                                        et_password.getText().toString());
                            if(userHelper.addOne(newAccount) == true) {
                                Toast.makeText(LogIn.this, "Created account: " +
                                                et_username.getText().toString(),
                                                Toast.LENGTH_SHORT).show();
                                et_username.setText("");
                                et_password.setText("");
                            }
                            else {
                                Toast.makeText(LogIn.this, "Error creating account",
                                        Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            Toast.makeText(LogIn.this, "Account already exists",
                                        Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                catch (Error e) {
                    Toast.makeText(LogIn.this, "Error creating account: " + e,
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}